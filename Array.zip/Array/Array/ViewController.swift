

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()

        useOfArraySlice()
    }
    
    func useOfInitWithEmptyArray(){
        var arrayOfStringsFirst: [String] = []       // type annotation + array literal
        var arrayOfStringsSecond = [String]()         // invoking the [String] initializer
        var arrayOfStringsThird = Array<String>()     // without syntactic sugar
        
        print("Array first = \(arrayOfStringsFirst)")
        print("Array second = \(arrayOfStringsFirst)")
        print("Array third = \(arrayOfStringsFirst)")
    }
    
    
    func useOfInitWithOtherSequence(){
        
           let setFirst : Set<Int> = [1,2,3,4,5,5]
           let arrayFromSet = Array(setFirst)
           print("Array From Set = \(arrayFromSet)")
        
           
           let dictFirst = ["first" : 1, "second" : 2]
           let arrayFromDict = Array(dictFirst)
           print("Array From Dictionary = \(arrayFromDict)")
       }
    
     func useOfArrayZip(){
    //        The zip function accepts 2 parameters of type SequenceType and returns a Zip2Sequence where each element contains a value from the first sequence and one from the second sequence.
            let nums = [1, 2, 3]
            let animals = ["Dog", "Cat", "Tiger"]
            let numOfAnimals = zip(nums, animals)
            let arrayNumAnimals = Array(numOfAnimals)  // return tuple array
            print("zip array = \(arrayNumAnimals[0].1)")
        }
    
       func useOfCOW(){
            //COW(Copy on Write)
    //        Copying an array will copy all of the items inside the original array. Changing the new array will not change the original array.
    //        Copied arrays will share the same space in memory as the original until they are changed. As a result of this there is a performance hit when the copied array is given its own space in memory as it is changed for the first time.
            var originalArray = ["Swift", "is", "great!"]
            var newArray = originalArray
            newArray[2] = "awesome!"
            print("New Array = \(newArray)")
            print("Original Array = \(originalArray)")
        }
    
    func useOfMultiDimensionalArray(){
           let array2x3 = [[1,2,3], [4,5,6]]
           print("Array 2x3 = \(array2x3)")
           let array3x4x5 = Array(repeating: Array(repeating: 0, count: 10), count: 5)
           print("Array 3x4x5 = \(array3x4x5)")
      //  [[0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]]
       }
       
      func useOfInitWithArrayLiteral(){
    //        An array literal is written with square brackets surrounding comma-separated elements:
            let arrayOfIntsFirst = [2, 4, 7]
    //        The compiler can usually infer the type of an array based on the elements in the literal, but explicit type annotations can override the default:
            let arrayOfIntSecond: [UInt] = [2, 4, 7] // type annotation on the variable
            let arrayOfIntThird = [2, 4, 7] as [Int] // type annotation on the initializer expression
            let arrayOfIntFour = [2 as UInt8, 4, 7] // explicit for one element, inferred for the others
            
            print("Array first = \(arrayOfIntsFirst)")
            print("Array second = \(arrayOfIntSecond)")
            print("Array third = \(arrayOfIntThird)")
            print("Array four = \(arrayOfIntFour)")
        }
    
    func useOfArraySlice(){
          let words = ["Hey", "Hello", "Bonjour", "Welcome", "Hi", "Hola"]
          let range = 2 ... 4
          let slice = words[range]
          let result = Array(slice)
          print("Array slice = \(result)")
      }
     
    
    
    
    
    
    
    
    
    
    
    
    
    //***********************************************
    
    
    

  
  
  
    
 

}

